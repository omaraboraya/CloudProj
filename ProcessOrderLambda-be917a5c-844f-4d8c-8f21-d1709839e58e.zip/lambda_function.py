import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Orders')  # This must match your table name
def lambda_handler(event, context):
    for record in event['Records']:
        message = json.loads(record['body'])

        table.put_item(Item={
            'OrderID': message['orderId'],
            'userId': message['userId'],
            'itemName': message['itemName'],
            'quantity': message['quantity'],
            'status': message['status'],
            'timestamp': message['timestamp']
        })

        print(f"📨 Confirmation sent to user {message['userId']} for order {message['orderId']}")
